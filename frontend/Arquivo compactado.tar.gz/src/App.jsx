import { useState, useEffect, useRef, useCallback } from "react";
import { auth as authApi, channels as chApi, stats as statsApi, files as filesApi, backup as backupApi } from "./api.js";

/* ─── GLOBAL STYLES ──────────────────────────────────────────────────────── */
const G = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&family=Outfit:wght@300;400;500;600&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg:        #080C12;
      --bg1:       #0C1119;
      --bg2:       #111824;
      --bg3:       #18212E;
      --border:    #1C2736;
      --border2:   #243040;
      --text:      #D8E6F3;
      --text2:     #6B8299;
      --text3:     #3D5166;
      --tg:        #2AABEE;
      --tg2:       #1A8FD1;
      --tg3:       rgba(42,171,238,0.12);
      --tg-glow:   rgba(42,171,238,0.2);
      --green:     #30D158;
      --yellow:    #FFD60A;
      --red:       #FF453A;
      --font:      'Outfit', sans-serif;
      --mono:      'JetBrains Mono', monospace;
      --display:   'Syne', sans-serif;
    }
    html, body, #root { height: 100%; background: var(--bg); color: var(--text); font-family: var(--font); }
    ::-webkit-scrollbar { width: 3px; height: 3px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 2px; }
    input, button { font-family: var(--font); }

    @keyframes fadeUp   { from { opacity:0; transform:translateY(14px) } to { opacity:1; transform:translateY(0) } }
    @keyframes fadeIn   { from { opacity:0 } to { opacity:1 } }
    @keyframes scaleIn  { from { opacity:0; transform:scale(0.94) } to { opacity:1; transform:scale(1) } }
    @keyframes spin     { to { transform:rotate(360deg) } }
    @keyframes pulse    { 0%,100%{opacity:1} 50%{opacity:.4} }
    @keyframes shimmer  { 0%{transform:translateX(-100%)} 100%{transform:translateX(100%)} }
    @keyframes glowPing { 0%{transform:scale(1);opacity:.8} 100%{transform:scale(2.2);opacity:0} }
    @keyframes countUp  { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }

    .anim-fu  { animation: fadeUp  .4s cubic-bezier(.22,1,.36,1) both }
    .anim-fu1 { animation: fadeUp  .4s .07s cubic-bezier(.22,1,.36,1) both }
    .anim-fu2 { animation: fadeUp  .4s .14s cubic-bezier(.22,1,.36,1) both }
    .anim-fu3 { animation: fadeUp  .4s .21s cubic-bezier(.22,1,.36,1) both }
    .anim-fu4 { animation: fadeUp  .4s .28s cubic-bezier(.22,1,.36,1) both }
    .anim-si  { animation: scaleIn .35s cubic-bezier(.22,1,.36,1) both }
    .anim-fi  { animation: fadeIn  .25s both }

    .card { background: var(--bg1); border: 1px solid var(--border); border-radius: 14px; }

    .btn {
      display: inline-flex; align-items: center; justify-content: center; gap: 7px;
      padding: 9px 18px; border-radius: 10px; border: none;
      font-size: 13.5px; font-weight: 500; cursor: pointer;
      transition: all .15s; white-space: nowrap;
    }
    .btn-primary {
      background: linear-gradient(135deg, var(--tg), var(--tg2));
      color: #fff; box-shadow: 0 2px 12px rgba(42,171,238,.3);
    }
    .btn-primary:hover:not(:disabled) { box-shadow: 0 4px 20px rgba(42,171,238,.45); transform: translateY(-1px); }
    .btn-primary:disabled { opacity: .5; cursor: not-allowed; transform: none !important; }
    .btn-ghost  { background: transparent; color: var(--text2); border: 1px solid var(--border); }
    .btn-ghost:hover { background: var(--bg2); border-color: var(--border2); color: var(--text); }
    .btn-danger { background: rgba(255,69,58,.1); color: var(--red); border: 1px solid rgba(255,69,58,.2); }
    .btn-sm { padding: 6px 13px; font-size: 12px; border-radius: 8px; }
    .btn-icon { width:34px; height:34px; padding:0; border-radius:9px; }

    .input {
      width: 100%; padding: 11px 14px;
      background: var(--bg); border: 1px solid var(--border);
      border-radius: 10px; color: var(--text); font-size: 14px; outline: none;
      transition: border-color .2s, box-shadow .2s;
    }
    .input:focus { border-color: var(--tg); box-shadow: 0 0 0 3px rgba(42,171,238,.1); }
    .input::placeholder { color: var(--text3); }

    .tag {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 3px 9px; border-radius: 20px;
      font-size: 11px; font-weight: 500; font-family: var(--mono);
    }
    .tag-blue   { background: var(--tg3); color: var(--tg); border: 1px solid rgba(42,171,238,.2); }
    .tag-green  { background: rgba(48,209,88,.1); color: var(--green); border: 1px solid rgba(48,209,88,.2); }
    .tag-yellow { background: rgba(255,214,10,.1); color: var(--yellow); border: 1px solid rgba(255,214,10,.2); }
    .tag-gray   { background: var(--bg2); color: var(--text2); border: 1px solid var(--border); }

    .divider { height: 1px; background: var(--border); }

    .progress { height: 5px; background: var(--bg3); border-radius: 3px; overflow: hidden; }
    .progress-fill {
      height: 100%; border-radius: 3px;
      background: linear-gradient(90deg, var(--tg), #60CFFF);
      position: relative; overflow: hidden;
      transition: width .6s cubic-bezier(.4,0,.2,1);
    }
    .progress-fill::after {
      content:''; position:absolute; inset:0;
      background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,.25) 50%, transparent 100%);
      animation: shimmer 1.8s infinite;
    }

    .sidebar {
      width: 210px; flex-shrink: 0;
      background: var(--bg1); border-right: 1px solid var(--border);
      display: flex; flex-direction: column;
    }
    .sidebar-logo {
      padding: 18px 16px 14px;
      border-bottom: 1px solid var(--border);
      display: flex; align-items: center; gap: 11px;
    }
    .logo-mark {
      width: 34px; height: 34px; border-radius: 9px; flex-shrink: 0;
      background: linear-gradient(145deg, var(--tg) 0%, #0D6FA8 100%);
      display: flex; align-items: center; justify-content: center;
      box-shadow: 0 0 16px rgba(42,171,238,.25);
    }
    .logo-text { font-family: var(--display); font-size: 15px; font-weight: 700; letter-spacing: -.3px; }
    .logo-text span { color: var(--tg); }

    .nav-section { padding: 12px 8px 8px; }
    .nav-section-label { font-size: 10px; font-weight: 600; color: var(--text3); text-transform: uppercase; letter-spacing: .1em; padding: 0 8px; margin-bottom: 4px; }

    .nav-item {
      display: flex; align-items: center; gap: 10px;
      padding: 9px 10px; border-radius: 9px;
      font-size: 13.5px; font-weight: 500; color: var(--text2);
      cursor: pointer; transition: all .15s; position: relative;
    }
    .nav-item:hover { background: var(--bg2); color: var(--text); }
    .nav-item.active { background: var(--tg3); color: var(--tg); }
    .nav-item.active::before {
      content:''; position:absolute; left:0; top:50%; transform:translateY(-50%);
      width: 3px; height: 55%; background: var(--tg); border-radius: 0 2px 2px 0;
    }

    .sidebar-bottom { margin-top: auto; padding: 10px 8px; border-top: 1px solid var(--border); }
    .user-row {
      display: flex; align-items: center; gap: 10px;
      padding: 8px 10px; border-radius: 9px; cursor: pointer; transition: background .15s;
    }
    .user-row:hover { background: var(--bg2); }
    .avatar {
      width: 30px; height: 30px; border-radius: 50%;
      background: linear-gradient(135deg, #1A8FD1, #0D5FA0);
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: 700; color: white; flex-shrink: 0;
    }
    .user-name  { font-size: 13px; font-weight: 500; }
    .user-phone { font-size: 11px; color: var(--text3); font-family: var(--mono); }

    .topbar {
      height: 50px; border-bottom: 1px solid var(--border);
      background: var(--bg1);
      display: flex; align-items: center; padding: 0 22px; gap: 14px; flex-shrink: 0;
    }
    .topbar-title { font-family: var(--display); font-size: 14px; font-weight: 600; }

    .status-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; position: relative; }
    .status-dot.green  { background: var(--green); }
    .status-dot.green::after { content:''; position:absolute; inset:-2px; border-radius:50%; background:var(--green); opacity:.3; animation: glowPing 2.5s infinite; }
    .status-dot.yellow { background: var(--yellow); animation: pulse 1.2s infinite; }
    .status-dot.gray   { background: var(--text3); }

    .stat-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
    .stat-card {
      background: var(--bg1); border: 1px solid var(--border);
      border-radius: 14px; padding: 18px 20px;
      position: relative; overflow: hidden;
      transition: border-color .2s, transform .15s;
    }
    .stat-card:hover { border-color: var(--border2); transform: translateY(-2px); }
    .stat-card::before {
      content:''; position:absolute; top:0; left:0; right:0; height:1px;
      background: linear-gradient(90deg, transparent, rgba(42,171,238,.3), transparent);
    }
    .stat-icon { width:36px; height:36px; border-radius:9px; display:flex; align-items:center; justify-content:center; margin-bottom:14px; }
    .stat-value { font-family: var(--display); font-size: 24px; font-weight: 700; line-height: 1; margin-bottom: 4px; animation: countUp .5s both; }
    .stat-label { font-size: 12px; color: var(--text2); }
    .stat-delta { font-size: 11px; margin-top: 6px; font-family: var(--mono); }

    .file-row {
      display: flex; align-items: center; gap: 10px;
      padding: 7px 10px; border-radius: 8px; cursor: pointer;
      transition: background .12s; font-size: 13px; user-select: none;
    }
    .file-row:hover { background: var(--bg2); }
    .file-row.selected { background: var(--tg3); color: var(--tg); }

    .ch-opt {
      border: 2px solid var(--border); border-radius: 12px;
      padding: 15px 16px; cursor: pointer;
      transition: all .2s; background: var(--bg); position: relative;
    }
    .ch-opt:hover { border-color: var(--border2); background: var(--bg1); }
    .ch-opt.sel   { border-color: var(--tg); background: rgba(42,171,238,.05); }
    .ch-opt-check {
      position:absolute; top:12px; right:12px;
      width:20px; height:20px; border-radius:50%;
      background: var(--tg); display:flex; align-items:center; justify-content:center;
      opacity:0; transform:scale(.6); transition: all .2s;
    }
    .ch-opt.sel .ch-opt-check { opacity:1; transform:scale(1); }

    .fp-item {
      background:var(--bg2); border:1px solid var(--border);
      border-radius:10px; padding:11px 8px;
      text-align:center; font-size:11.5px; color:var(--text2);
      transition: all .2s; cursor:pointer;
    }
    .fp-item:hover { border-color:var(--border2); }
    .fp-item.on { border-color:rgba(42,171,238,.4); background:rgba(42,171,238,.06); color:var(--tg); }
    .fp-emoji { font-size:19px; display:block; margin-bottom:5px; }

    .log-item { display:flex; gap:12px; padding:10px 0; border-bottom:1px solid var(--border); font-size:13px; }
    .log-item:last-child { border:none; }

    .bk-item {
      display:flex; align-items:center; gap:12px;
      padding:11px 14px; border-radius:10px;
      background:var(--bg2); border:1px solid var(--border);
      font-size:13px; margin-bottom:6px; transition:border-color .2s;
    }
    .bk-item-icon { width:34px; height:34px; border-radius:9px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }

    .sched-row {
      display:flex; align-items:center; justify-content:space-between;
      padding:13px 14px; border-radius:10px;
      background:var(--bg2); border:1px solid var(--border); margin-bottom:8px;
    }

    .toggle { width:38px; height:22px; border-radius:11px; border:none; cursor:pointer; transition:background .2s; position:relative; flex-shrink:0; }
    .toggle.on  { background:var(--tg); }
    .toggle.off { background:var(--bg3); }
    .toggle-knob { position:absolute; top:3px; width:16px; height:16px; border-radius:50%; background:white; transition:left .2s; box-shadow:0 1px 4px rgba(0,0,0,.3); }
    .toggle.on  .toggle-knob { left:19px; }
    .toggle.off .toggle-knob { left:3px; }

    .wizard-wrap {
      height:100vh; display:flex; align-items:center; justify-content:center;
      background:
        radial-gradient(ellipse 60% 50% at 20% 10%, rgba(42,171,238,.07) 0%, transparent 70%),
        radial-gradient(ellipse 50% 40% at 85% 85%, rgba(26,111,168,.05) 0%, transparent 70%),
        var(--bg);
    }
    .wizard-card {
      width:460px; background:var(--bg1);
      border:1px solid var(--border); border-radius:22px;
      padding:40px; position:relative; overflow:hidden;
    }
    .wizard-card::before {
      content:''; position:absolute; top:0; left:0; right:0; height:1px;
      background:linear-gradient(90deg, transparent 10%, rgba(42,171,238,.5) 50%, transparent 90%);
    }
    .wiz-step-bar { display:flex; gap:5px; margin-bottom:28px; }
    .wiz-dot { height:3px; flex:1; border-radius:2px; background:var(--border); transition:background .3s; }
    .wiz-dot.done   { background:rgba(42,171,238,.4); }
    .wiz-dot.active { background:var(--tg); }
    .wiz-logo {
      width:50px; height:50px; border-radius:15px;
      background:linear-gradient(145deg, var(--tg) 0%, #0A60A0 100%);
      display:flex; align-items:center; justify-content:center;
      box-shadow:0 0 28px rgba(42,171,238,.3); margin-bottom:20px;
    }
    .wiz-title { font-family:var(--display); font-size:22px; font-weight:700; margin-bottom:6px; letter-spacing:-.3px; }
    .wiz-sub   { font-size:13.5px; color:var(--text2); margin-bottom:24px; line-height:1.6; }
    .form-lbl  { font-size:11px; font-weight:600; color:var(--text2); text-transform:uppercase; letter-spacing:.08em; display:block; margin-bottom:7px; }
    .form-grp  { margin-bottom:16px; }

    .fp-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin:14px 0; }

    .empty { text-align:center; padding:50px 20px; color:var(--text2); }
    .empty-icon { font-size:42px; margin-bottom:14px; }
    .empty-title { font-size:16px; font-weight:600; color:var(--text); margin-bottom:6px; }
    .empty-sub   { font-size:13px; line-height:1.6; }

    .flex     { display:flex; }
    .flex-col { flex-direction:column; }
    .items-center { align-items:center; }
    .justify-between { justify-content:space-between; }
    .gap-2 { gap:8px; }
    .gap-3 { gap:12px; }
    .gap-4 { gap:16px; }
    .ml-auto { margin-left:auto; }
    .w-full  { width:100%; }
    .mono    { font-family:var(--mono); }
    .pointer { cursor:pointer; }
  `}</style>
);

/* ─── ICONS ──────────────────────────────────────────────────────────────── */
const icPaths = {
  home:     <><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></>,
  cloud:    <path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/>,
  folder:   <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></>,
  activity: <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>,
  shield:   <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>,
  plus:     <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
  check:    <polyline points="20 6 9 17 4 12" strokeWidth="2.5"/>,
  arrow:    <><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></>,
  arrowL:   <><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></>,
  refresh:  <><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></>,
  clock:    <><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></>,
  zap:      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" strokeWidth="1.6"/>,
  file:     <><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></>,
  play:     <polygon points="5 3 19 12 5 21 5 3" fill="currentColor" stroke="none"/>,
  tg:       <path d="M12 0C5.37 0 0 5.37 0 12s5.37 12 12 12 12-5.37 12-12S18.63 0 12 0zm5.89 8.22l-1.97 9.28c-.14.66-.54.82-1.08.51l-3-2.21-1.45 1.39c-.16.16-.29.29-.6.29l.21-3.05 5.56-5.02c.24-.21-.05-.33-.37-.12L6.21 13.8l-2.96-.92c-.64-.2-.66-.64.14-.95l11.57-4.46c.53-.2 1.01.13.83.95z" fill="currentColor" stroke="none"/>,
  trash:    <><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6M9 6V4h6v2"/></>,
  download: <><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></>,
  upload:   <><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></>,
  link:     <><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></>,
  bell:     <><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></>,
  info:     <><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8" strokeWidth="2.5"/></>,
};
const Icon = ({ n, size = 16, color }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color || "currentColor"}
    strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
    {icPaths[n]}
  </svg>
);

/* ─── DATA ───────────────────────────────────────────────────────────────── */
/* mock data removido — dados vêm do backend agora */
const FILE_ICON = {pdf:"📄",xls:"📊",xlsx:"📊",ppt:"📑",pptx:"📑",doc:"📝",docx:"📝",txt:"📋",md:"📋",jpg:"🖼️",jpeg:"🖼️",png:"🖼️",gif:"🖼️",mp4:"🎬",mkv:"🎬",mp3:"🎵",flac:"🎵",zip:"🗜️",gz:"🗜️",tar:"🗜️",rar:"🗜️","7z":"🗜️",py:"💾",js:"💾",jsx:"💾",java:"💾",sh:"💾",json:"💾",dir:"📁",file:"📄",appimage:"🗜️"};

/** Separa "MarcosQueiroz" → "Marcos Queiroz" */
const splitName = (name) => name ? name.replace(/([a-z])([A-Z])/g, "$1 $2") : "...";
/* BK_ITEMS_INIT removido — backup agora usa dados reais via SSE */

/* ─── HELPERS ─────────────────────────────────────────────────────────────── */
const Spinner = ({size=16}) => (
  <div style={{width:size,height:size,borderRadius:"50%",border:`2px solid rgba(255,255,255,.2)`,borderTopColor:"white",animation:"spin 1s linear infinite",flexShrink:0}}/>
);
const Toggle = ({on,onToggle}) => (
  <button className={`toggle ${on?"on":"off"}`} onClick={onToggle} style={{outline:"none"}}>
    <div className="toggle-knob"/>
  </button>
);

/* ─── WIZARD ──────────────────────────────────────────────────────────────── */

function Wizard({onDone}) {
  const [step,setStep] = useState(0);
  const [phone,setPhone] = useState("+55 ");
  const [code,setCode] = useState("");
  const [loading,setLoading] = useState(false);
  const [error,setError] = useState("");

  const load = async (cb) => {
    setLoading(true);
    try { await cb(); }
    catch(e) { setError(e?.response?.data?.detail || e.message || "Erro desconhecido"); }
    finally { setLoading(false); }
  };

  return (
    <div className="wizard-wrap">
      <div className="wizard-card">
        {/* STEP 0: phone */}
        {step===0 && <div className="anim-si">
          <div className="wiz-logo"><Icon n="tg" size={24} color="white"/></div>
          <div className="wiz-step-bar">{[0,1,2].map(i=><div key={i} className={`wiz-dot ${i===0?"active":""}`}/>)}</div>
          <div className="wiz-title">Conectar ao Telegram</div>
          <div className="wiz-sub">Autorize o TeleVault a acessar seu armazenamento pessoal via API oficial Telegram.</div>
          <div className="form-grp">
            <label className="form-lbl">Número de telefone</label>
            <input className="input" value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+55 11 99999-9999" style={{fontSize:15,letterSpacing:".02em"}}/>
          </div>
          <div style={{fontSize:12,color:"var(--text3)",marginBottom:20,lineHeight:1.7,padding:"10px 12px",background:"var(--bg2)",borderRadius:9,border:"1px solid var(--border)"}}>
            <span style={{color:"var(--tg)"}}>ℹ</span>  Seus dados nunca saem do seu próprio armazenamento Telegram. Zero servidores terceiros.
          </div>
          <button className="btn btn-primary w-full" style={{padding:"12px",fontSize:14}} onClick={()=>load(async()=>{setError("");await authApi.sendCode(phone);setStep(1);})} disabled={loading}>
            {loading?<><Spinner/>Enviando...</>:<><span>Enviar código</span><Icon n="arrow" size={14}/></>}
          </button>
          {error&&<div style={{marginTop:12,padding:"10px 12px",background:"rgba(255,69,58,.08)",border:"1px solid rgba(255,69,58,.2)",borderRadius:9,fontSize:12.5,color:"var(--red)"}}>{error}</div>}
        </div>}

        {/* STEP 1: code */}
        {step===1 && <div className="anim-si">
          <div className="wiz-logo" style={{background:"linear-gradient(145deg,#30D158,#1A8A3A)"}}><Icon n="check" size={22} color="white"/></div>
          <div className="wiz-step-bar">{[0,1,2].map(i=><div key={i} className={`wiz-dot ${i===1?"active":i<1?"done":""}`}/>)}</div>
          <div className="wiz-title">Verificar identidade</div>
          <div className="wiz-sub">Digite o código de 5 dígitos enviado para o seu Telegram agora.</div>
          <div className="form-grp">
            <label className="form-lbl">Código de verificação</label>
            <input className="input" value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,"").slice(0,5))}
              placeholder="• • • • •" style={{fontSize:22,letterSpacing:"0.4em",textAlign:"center",fontFamily:"var(--mono)",padding:"14px"}}/>
          </div>
          <button className="btn btn-primary w-full" style={{padding:"12px",fontSize:14,marginBottom:10}} onClick={()=>load(async()=>{setError("");await authApi.signIn(code);setStep(2);})} disabled={loading||code.length<5}>
            {loading?<><Spinner/>Verificando...</>:<><span>Confirmar</span><Icon n="arrow" size={14}/></>}
          </button>
          {error&&<div style={{marginTop:10,padding:"10px 12px",background:"rgba(255,69,58,.08)",border:"1px solid rgba(255,69,58,.2)",borderRadius:9,fontSize:12.5,color:"var(--red)"}}>{error}</div>}
          <button className="btn btn-ghost w-full" style={{padding:"10px",marginTop:8}} onClick={()=>{setStep(0);setError("");}}><Icon n="arrowL" size={14}/>Voltar</button>
        </div>}

        {/* STEP 2: done */}
        {step===2 && <div className="anim-si" style={{maxHeight:"80vh",overflowY:"auto"}}>
          <div className="wiz-logo" style={{background:"linear-gradient(145deg,#30D158,#1A8A3A)"}}><Icon n="check" size={24} color="white"/></div>
          <div className="wiz-step-bar">{[0,1,2].map(i=><div key={i} className={`wiz-dot ${i===2?"active":"done"}`}/>)}</div>
          <div className="wiz-title">Tudo pronto!</div>
          <div className="wiz-sub">Autenticação concluída. O TeleVault vai usar o canal configurado no servidor para armazenar seus backups.</div>

          <div style={{padding:"14px 16px",background:"var(--bg2)",borderRadius:10,border:"1px solid var(--border)",marginBottom:20}}>
            <div className="flex items-center gap-3">
              <span style={{fontSize:22}}>📦</span>
              <div>
                <div style={{fontSize:13,fontWeight:600}}>Canal de backup</div>
                <div style={{fontSize:12,color:"var(--text2)",fontFamily:"var(--mono)",marginTop:2}}>Configurado via TELEVAULT_CHANNEL_ID no servidor</div>
              </div>
              <span className="tag tag-green" style={{marginLeft:"auto"}}>Ativo</span>
            </div>
          </div>

          <div style={{fontSize:12,color:"var(--text3)",marginBottom:20,lineHeight:1.7,padding:"10px 12px",background:"var(--bg2)",borderRadius:9,border:"1px solid var(--border)"}}>
            <span style={{color:"var(--tg)"}}>ℹ</span>  Seus arquivos são enviados diretamente para o seu canal privado no Telegram. Nenhum servidor terceiro é envolvido.
          </div>

          <button className="btn btn-primary w-full" style={{padding:"12px",fontSize:14}} onClick={()=>load(onDone)} disabled={loading}>
            {loading?<><Spinner/>Carregando...</>:<><Icon n="zap" size={15}/><span>Começar a usar</span></>}
          </button>
        </div>}
      </div>
    </div>
  );
}

/* ─── DASHBOARD ──────────────────────────────────────────────────────────── */
function Dashboard({setPage,runBackup,backupRunning,backupProgress,user,realChannels,realStats,channelId,activityLog}) {
  const pct = backupProgress?.current?.percent || (backupProgress ? Math.round((backupProgress.done/Math.max(backupProgress.total,1))*100) : 0);

  return (
    <div style={{padding:26}}>
      {/* header */}
      <div className="flex items-center justify-between anim-fu" style={{marginBottom:22}}>
        <div>
          <div style={{fontFamily:"var(--display)",fontSize:21,fontWeight:700,letterSpacing:"-.3px"}}>Olá, {splitName(user?.first_name)} 👋</div>
          <div style={{fontSize:12.5,color:"var(--text2)",marginTop:3}}>{realChannels.length>0?<>Canal: <span style={{color:"var(--tg)",fontFamily:"var(--mono)"}}>{realChannels[0]?.name}</span></>:<span style={{color:"var(--text3)"}}>Nenhum canal configurado</span>}</div>
        </div>
        <button className="btn btn-primary" onClick={()=>backupRunning?null:setPage("backup")} disabled={backupRunning} style={{padding:"10px 20px"}}>
          {backupRunning?<><Spinner/><span>Em andamento...</span></>:<><Icon n="cloud" size={15}/><span>Backup agora</span></>}
        </button>
      </div>

      {/* stats */}
      <div className="stat-grid anim-fu1" style={{marginBottom:22}}>
        {[
          {icon:"cloud",  bg:"rgba(42,171,238,.12)", color:"var(--tg)",    val:realStats?.total_size||"...", label:"Armazenado",    delta:realStats?`${realStats.total_files} arquivos`:"carregando...", dc:"var(--tg)"},
          {icon:"folder", bg:"rgba(48,209,88,.12)",  color:"var(--green)", val:realStats?.total_files?.toLocaleString("pt-BR")||"...", label:"Arquivos", delta:realChannels.length>0?`${realChannels.length} canal(is)`:"sem canal", dc:"var(--green)"},
          {icon:"clock",  bg:"rgba(255,159,10,.12)", color:"#FF9F0A",      val:realStats?.last_backup?new Date(realStats.last_backup).toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"}):"—", label:"Último backup", delta:realStats?.last_backup?new Date(realStats.last_backup).toLocaleDateString("pt-BR"):"nunca", dc:"var(--text2)"},
          {icon:"shield", bg:"rgba(191,90,242,.12)", color:"#BF5AF2",      val:realChannels.length>0?"online":"—", label:"Telegram", delta:realChannels[0]?.name||"sem canal", dc:"var(--green)"},
        ].map((s,i)=>(
          <div key={i} className="stat-card">
            <div className="stat-icon" style={{background:s.bg}}><Icon n={s.icon} size={17} color={s.color}/></div>
            <div className="stat-value" style={{fontSize:s.val.length>6?19:24}}>{s.val}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-delta" style={{color:s.dc}}>{s.delta}</div>
          </div>
        ))}
      </div>

      <div className="anim-fu2" style={{display:"grid",gridTemplateColumns:"1fr 320px",gap:16}}>
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          {/* backup status */}
          <div className="card" style={{padding:20}}>
            <div className="flex items-center justify-between" style={{marginBottom:16}}>
              <div className="flex items-center gap-3">
                <div className={`status-dot ${backupRunning?"yellow":"green"}`}/>
                <span style={{fontWeight:600,fontSize:14}}>{backupRunning?"Backup em andamento":"Sistema operacional"}</span>
              </div>
              <span className={`tag ${backupRunning?"tag-yellow":"tag-green"}`} style={backupRunning?{animation:"pulse 1.5s infinite"}:{}}>
                {backupRunning?"LIVE":"IDLE"}
              </span>
            </div>
            {backupRunning?(
              <div>
                <div className="flex justify-between" style={{fontSize:12,color:"var(--text2)",marginBottom:7}}>
                  <span>Enviando para Telegram... {backupProgress?`${backupProgress.done}/${backupProgress.total} arquivos`:""}</span>
                  <span className="mono">{pct}%</span>
                </div>
                <div className="progress"><div className="progress-fill" style={{width:`${pct}%`}}/></div>
                <div style={{fontSize:11.5,color:"var(--text3)",marginTop:8,fontFamily:"var(--mono)"}}>
                  {backupProgress?.current ? `→ ${backupProgress.current.filename} (${backupProgress.current.speed_mbps} MB/s)` : "preparando..."}
                </div>
              </div>
            ):(
              <div>
                <div className="flex justify-between" style={{fontSize:12,color:"var(--text2)",marginBottom:7}}>
                  <span>Armazenamento utilizado</span>
                  <span className="mono">{realStats?.total_size||"..."} / ∞</span>
                </div>
                <div className="progress"><div className="progress-fill" style={{width:"20%"}}/></div>
                <div style={{fontSize:12,color:"var(--text3)",marginTop:8}}>Próximo backup automático: <span style={{color:"var(--text2)"}}>—</span></div>
              </div>
            )}
          </div>

          {/* folders list */}
          <div className="card" style={{padding:20}}>
            <div className="flex items-center justify-between" style={{marginBottom:14}}>
              <div>
                <span style={{fontWeight:600,fontSize:14}}>Arquivos por tipo</span>
                {realStats?.total_files>0&&<span className="tag tag-green" style={{marginLeft:8,fontSize:10}}>{realStats.total_files} total</span>}
              </div>
              <button className="btn btn-ghost btn-sm" onClick={()=>setPage("files")}><Icon n="arrow" size={13}/>Ver todos</button>
            </div>
            {(realStats?.folders||[]).length>0 ? (realStats.folders.map((f,i)=>(
              <div key={i} className="flex items-center" style={{padding:"8px 10px",borderRadius:9,cursor:"pointer",transition:"background .12s",gap:12}}
                onMouseEnter={e=>e.currentTarget.style.background="var(--bg2)"}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <span style={{fontSize:17,width:26,textAlign:"center"}}>{f.emoji}</span>
                <span style={{flex:1,fontSize:13,fontWeight:500}}>{f.label}</span>
                <span style={{fontSize:11,color:"var(--text3)",fontFamily:"var(--mono)"}}>{f.count} arq.</span>
                <span style={{fontSize:11,color:"var(--text2)",fontFamily:"var(--mono)",width:58,textAlign:"right"}}>{f.size}</span>
              </div>
            ))) : (
              <div style={{padding:"20px 0",textAlign:"center",color:"var(--text3)",fontSize:13}}>
                {realStats ? "Nenhum arquivo no canal ainda." : "Carregando..."}
              </div>
            )}
          </div>
        </div>

        {/* activity */}
        <div className="card anim-fu3" style={{padding:20,height:"fit-content"}}>
          <div className="flex items-center justify-between" style={{marginBottom:14}}>
            <span style={{fontWeight:600,fontSize:14}}>Atividade recente</span>
            <Icon n="activity" size={14} color="var(--text3)"/>
          </div>
          {activityLog.length>0 ? activityLog.slice(0,6).map((l,i)=>(
            <div key={i} className="log-item">
              <span style={{fontSize:15,flexShrink:0}}>{l.e}</span>
              <div style={{flex:1}}>
                <div style={{fontSize:12.5,lineHeight:1.5}}>{l.text}</div>
                <div style={{fontSize:10.5,color:"var(--text3)",fontFamily:"var(--mono)",marginTop:2}}>{l.time}</div>
              </div>
            </div>
          )) : (
            <div style={{padding:"24px 0",textAlign:"center"}}>
              <div style={{fontSize:28,marginBottom:8}}>📭</div>
              <div style={{fontSize:13,color:"var(--text2)",marginBottom:4}}>Sem atividade ainda</div>
              <div style={{fontSize:12,color:"var(--text3)"}}>Faça um upload ou backup para ver registros aqui.</div>
            </div>
          )}
          {activityLog.length>6&&(
            <button className="btn btn-ghost btn-sm w-full" style={{marginTop:12}} onClick={()=>setPage("activity")}>
              Ver histórico completo
            </button>
          )}
        </div>
      </div>
    </div>
  );
}


/* ─── FILES ──────────────────────────────────────────────────────────────── */
const MAX_UPLOAD_MB = 2000;

function FilesPage({realChannels,addLog}) {
  const [selF,setSelF]=useState(realChannels[0]?.id||null);
  const [selFile,setSelFile]=useState(null);
  const [realFiles,setRealFiles]=useState([]);
  const [loadingFiles,setLoadingFiles]=useState(false);
  const [deleting,setDeleting]=useState(null);
  const fileInput=useRef(null);

  // upload state
  const [uploading,setUploading]=useState(false);
  const [uploadPhase,setUploadPhase]=useState("");  // "" | "sending" | "telegram" | "done" | "error"
  const [uploadName,setUploadName]=useState("");
  const [uploadSize,setUploadSize]=useState(0);
  const [httpProg,setHttpProg]=useState(0);        // % do browser → servidor
  const [tgProg,setTgProg]=useState(0);            // % do servidor → Telegram
  const [tgSpeed,setTgSpeed]=useState(0);          // MB/s
  const [uploadError,setUploadError]=useState("");
  const sseRef=useRef(null);

  const loadFiles = async (chId) => {
    if(!chId) return;
    setLoadingFiles(true);
    try {
      const r = await filesApi.list(chId, 100);
      setRealFiles(r.data.files||[]);
    } catch(e){ console.warn(e); }
    finally { setLoadingFiles(false); }
  };

  useEffect(()=>{ if(selF) loadFiles(selF); },[selF]);

  // cleanup SSE on unmount
  useEffect(()=>()=>{ if(sseRef.current) sseRef.current.close(); },[]);

  const resetUpload = () => {
    setUploading(false); setUploadPhase(""); setUploadName(""); setUploadSize(0);
    setHttpProg(0); setTgProg(0); setTgSpeed(0); setUploadError("");
    if(sseRef.current){ sseRef.current.close(); sseRef.current=null; }
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if(!file||!selF) return;
    e.target.value = "";  // reset input para permitir reenvio do mesmo arquivo

    // validação tamanho
    const sizeMB = file.size / 1048576;
    if(sizeMB > MAX_UPLOAD_MB){
      alert(`Arquivo muito grande (${sizeMB.toFixed(0)} MB). Limite: ${MAX_UPLOAD_MB} MB.`);
      return;
    }

    // reset e inicia
    resetUpload();
    setUploading(true);
    setUploadPhase("sending");
    setUploadName(file.name);
    setUploadSize(file.size);

    try {
      // Fase 1: browser → servidor (com progresso HTTP)
      const res = await filesApi.upload(selF, file, (ev)=>{
        if(ev.total) setHttpProg(Math.round((ev.loaded/ev.total)*100));
      });

      const uploadId = res.data?.upload_id;
      if(!uploadId) throw new Error("Servidor não retornou upload_id");

      // Fase 2: servidor → Telegram (via SSE)
      setUploadPhase("telegram");
      setHttpProg(100);

      const es = filesApi.streamUploadProgress(uploadId, (data) => {
        if(data.error) {
          setUploadPhase("error");
          setUploadError(data.error);
          setUploading(false);
          return;
        }
        setTgProg(data.tg_percent || 0);
        setTgSpeed(data.speed_mbps || 0);

        if(data.done) {
          setUploadPhase("done");
          setUploading(false);
          addLog?.("📤",`Upload: ${file.name} (${sizeMB.toFixed(1)} MB)`);
          loadFiles(selF);
          // auto-dismiss after 3s
          setTimeout(resetUpload, 3000);
        }
      });
      sseRef.current = es;

    } catch(err){
      const msg = err?.response?.data?.detail || err.message || "Erro desconhecido";
      setUploadPhase("error");
      setUploadError(msg);
      setUploading(false);
    }
  };

  const handleDownload = (f) => {
    if(!selF || !f.message_id) return;
    const url = filesApi.downloadUrl(selF, f.message_id);
    window.open(url, "_blank");
    addLog?.("📥",`Download: ${f.filename}`);
  };

  const handleDelete = async (f) => {
    if(!selF || !f.message_id) return;
    if(!confirm(`Apagar "${f.filename}" do Telegram?`)) return;
    setDeleting(f.message_id);
    try {
      await filesApi.delete(selF, f.message_id);
      addLog?.("🗑️",`Deletado: ${f.filename}`);
      await loadFiles(selF);
    } catch(err){ alert("Erro ao deletar: " + (err?.response?.data?.detail||err.message)); }
    finally { setDeleting(null); }
  };

  const fmtSize = (b) => b > 1073741824 ? `${(b/1073741824).toFixed(1)} GB` : b > 1048576 ? `${(b/1048576).toFixed(1)} MB` : `${Math.round(b/1024)} KB`;

  const displayFiles = realFiles.map(f=>({
    ...f,
    name: f.filename,
    size: fmtSize(f.size),
    date: new Date(f.date).toLocaleDateString("pt-BR"),
    type: f.filename.split(".").pop()?.toLowerCase()||"file",
  }));

  // progresso combinado (0-100 total: 0-30 = HTTP, 30-100 = Telegram)
  const combinedProg = uploadPhase==="sending" ? Math.round(httpProg*0.3)
    : uploadPhase==="telegram" ? 30 + Math.round(tgProg*0.7)
    : uploadPhase==="done" ? 100 : 0;

  const phaseLabel = uploadPhase==="sending" ? `Recebendo no servidor... ${httpProg}%`
    : uploadPhase==="telegram" ? `Enviando pro Telegram... ${tgProg}% · ${tgSpeed} MB/s`
    : uploadPhase==="done" ? "Concluído!"
    : uploadPhase==="error" ? `Erro: ${uploadError}`
    : "";

  return (
    <div style={{display:"flex",height:"100%",overflow:"hidden"}}>
      {/* channel sidebar */}
      <div style={{width:210,borderRight:"1px solid var(--border)",padding:14,overflow:"auto",flexShrink:0}}>
        <div style={{fontSize:10,fontWeight:600,color:"var(--text3)",textTransform:"uppercase",letterSpacing:".1em",marginBottom:10}}>Canais</div>
        {realChannels.length>0 ? realChannels.map(ch=>(
          <div key={ch.id} className={`file-row ${selF===ch.id?"selected":""}`} onClick={()=>{setSelF(ch.id);setSelFile(null);}}>
            <span style={{fontSize:15}}>📦</span>
            <span style={{flex:1,fontSize:12.5,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{ch.name}</span>
          </div>
        )) : (
          <div style={{padding:"20px 10px",color:"var(--text3)",fontSize:12,textAlign:"center"}}>Nenhum canal encontrado</div>
        )}
      </div>

      {/* file list */}
      <div style={{flex:1,overflow:"auto",padding:22}}>
        {/* upload progress bar */}
        {(uploading||uploadPhase==="done"||uploadPhase==="error")&&(
          <div style={{padding:"12px 14px",marginBottom:14,background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12}}>
            <div className="flex items-center justify-between" style={{marginBottom:8}}>
              <div className="flex items-center gap-2">
                {uploadPhase==="done"?<Icon n="check" size={14} color="var(--green)"/>
                  :uploadPhase==="error"?<Icon n="info" size={14} color="var(--red)"/>
                  :<Spinner size={14}/>}
                <span style={{fontSize:13,fontWeight:500,color:uploadPhase==="error"?"var(--red)":"var(--text)"}}>{uploadName}</span>
                <span style={{fontSize:11,color:"var(--text3)",fontFamily:"var(--mono)"}}>{fmtSize(uploadSize)}</span>
              </div>
              {uploadPhase==="error"&&<button className="btn btn-ghost btn-sm" onClick={resetUpload} style={{padding:"4px 10px",fontSize:11}}>Fechar</button>}
            </div>
            <div className="progress" style={{marginBottom:6}}><div className="progress-fill" style={{width:`${combinedProg}%`,background:uploadPhase==="done"?"var(--green)":uploadPhase==="error"?"var(--red)":undefined}}/></div>
            <div style={{fontSize:11.5,color:uploadPhase==="error"?"var(--red)":"var(--text2)",fontFamily:"var(--mono)"}}>{phaseLabel}</div>
          </div>
        )}

        <div className="flex items-center justify-between" style={{marginBottom:16}}>
          <div>
            <div style={{fontFamily:"var(--display)",fontSize:17,fontWeight:700}}>{realChannels.find(c=>c.id===selF)?.name||"Canal"}</div>
            <div style={{fontSize:12,color:"var(--text2)",marginTop:2}}>{loadingFiles?"carregando...":`${displayFiles.length} arquivos`}</div>
          </div>
          <div className="flex gap-2">
            <input ref={fileInput} type="file" style={{display:"none"}} onChange={handleUpload}/>
            <button className="btn btn-ghost btn-sm" onClick={()=>fileInput.current?.click()} disabled={uploading}>
              {uploading?<><Spinner size={12}/>{combinedProg}%</>:<><Icon n="upload" size={13}/>Enviar</>}
            </button>
            <button className="btn btn-ghost btn-sm" onClick={()=>loadFiles(selF)} disabled={loadingFiles}>
              <Icon n="refresh" size={13}/>{loadingFiles?"...":"Atualizar"}
            </button>
          </div>
        </div>

        <div className="flex" style={{padding:"5px 10px",fontSize:10.5,color:"var(--text3)",fontWeight:600,textTransform:"uppercase",letterSpacing:".08em",marginBottom:4,gap:10}}>
          <div style={{flex:1}}>Nome</div>
          <div style={{width:70,textAlign:"right"}}>Tamanho</div>
          <div style={{width:110,textAlign:"right"}}>Data</div>
          <div style={{width:80}}></div>
        </div>

        {loadingFiles?(<div style={{textAlign:'center',padding:'40px',color:'var(--text3)'}}><Spinner size={24}/></div>):displayFiles.length===0?(
          <div className="empty">
            <div className="empty-icon">📭</div>
            <div className="empty-title">Canal vazio</div>
            <div className="empty-sub">Envie um arquivo ou faça um backup para popular este canal.</div>
          </div>
        ):displayFiles.map((f,i)=>(
          <div key={f.message_id||i} className={`file-row ${selFile===i?"selected":""}`} style={{padding:"10px 10px",gap:10}} onClick={()=>setSelFile(i)}>
            <span style={{fontSize:17,width:26,textAlign:"center",flexShrink:0}}>{FILE_ICON[f.type]||"📄"}</span>
            <span style={{flex:1,fontSize:13,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{f.name}</span>
            <span style={{width:70,textAlign:"right",fontSize:11.5,color:"var(--text3)",fontFamily:"var(--mono)"}}>{f.size}</span>
            <span style={{width:110,textAlign:"right",fontSize:11.5,color:"var(--text2)",fontFamily:"var(--mono)"}}>{f.date}</span>
            <div className="flex gap-2" style={{width:80,justifyContent:"flex-end"}} onClick={e=>e.stopPropagation()}>
              <button className="btn btn-ghost btn-icon btn-sm" title="Baixar" onClick={()=>handleDownload(f)}><Icon n="download" size={13}/></button>
              <button className="btn btn-ghost btn-icon btn-sm" title="Deletar" onClick={()=>handleDelete(f)} disabled={deleting===f.message_id}>
                {deleting===f.message_id?<Spinner size={12}/>:<Icon n="trash" size={13}/>}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── BACKUP ──────────────────────────────────────────────────────────────── */
function BackupPage({runBackup,backupRunning,backupProgress,channelId}) {
  const [pathInput,setPathInput]=useState("");
  const [paths,setPaths]=useState([]);
  const [scheds,setScheds]=useState([
    {label:"A cada hora",  sub:"Verifica mudanças toda hora",       on:false},
    {label:"2x ao dia",   sub:"12h e 20h automaticamente",         on:true},
    {label:"Diário 20h",  sub:"Backup completo diário",             on:true},
    {label:"Ao iniciar",  sub:"Backup ao ligar o computador",       on:true},
  ]);

  const addPath = () => {
    const p = pathInput.trim();
    if(p && !paths.includes(p)) { setPaths(prev=>[...prev,p]); setPathInput(""); }
  };
  const removePath = (i) => setPaths(prev=>prev.filter((_,j)=>j!==i));
  const handleStart = () => { if(paths.length>0) runBackup(paths); };

  const totalPct = backupProgress ? Math.round((backupProgress.done/Math.max(backupProgress.total,1))*100) : 0;
  const isDone = backupProgress?.status==="done";

  return (
    <div style={{padding:26}}>
      <div className="anim-fu" style={{fontFamily:"var(--display)",fontSize:19,fontWeight:700,marginBottom:20}}>Backup & Sincronização</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 290px",gap:16}}>
        <div style={{display:"flex",flexDirection:"column",gap:16}}>

          {/* path selector */}
          <div className="card anim-fu1" style={{padding:20}}>
            <div style={{fontWeight:600,marginBottom:14}}>Pastas / arquivos para backup</div>
            <div className="flex gap-2" style={{marginBottom:12}}>
              <input className="input" value={pathInput} onChange={e=>setPathInput(e.target.value)}
                placeholder="/home/marcos/Documentos" style={{fontSize:13}}
                onKeyDown={e=>{ if(e.key==="Enter") addPath(); }}/>
              <button className="btn btn-ghost btn-sm" onClick={addPath} disabled={!pathInput.trim()}><Icon n="plus" size={13}/>Adicionar</button>
            </div>
            {paths.length===0 ? (
              <div style={{fontSize:12.5,color:"var(--text3)",padding:"10px 0"}}>Nenhum caminho adicionado. Digite o caminho completo e pressione Enter.</div>
            ) : paths.map((p,i)=>(
              <div key={i} className="flex items-center gap-2" style={{padding:"7px 10px",background:"var(--bg2)",borderRadius:8,marginBottom:4,border:"1px solid var(--border)"}}>
                <span style={{fontSize:14}}>📁</span>
                <span style={{flex:1,fontSize:12.5,fontFamily:"var(--mono)",color:"var(--text2)"}}>{p}</span>
                <button className="btn btn-ghost btn-icon btn-sm" onClick={()=>removePath(i)} style={{width:26,height:26}}><Icon n="trash" size={12}/></button>
              </div>
            ))}
            <button className="btn btn-primary w-full" style={{marginTop:12,padding:"11px",fontSize:14}} onClick={handleStart}
              disabled={backupRunning || paths.length===0 || !channelId}>
              {backupRunning?<><Spinner size={14}/>Backup em andamento...</>:!channelId?<span>Sem canal configurado</span>:<><Icon n="play" size={13}/>Iniciar backup ({paths.length} caminho{paths.length>1?"s":""})</>}
            </button>
          </div>

          {/* live progress */}
          <div className="card anim-fu2" style={{padding:20}}>
            <div className="flex items-center justify-between" style={{marginBottom:16}}>
              <span style={{fontWeight:600}}>Progresso do backup</span>
              {backupRunning && <span className="tag tag-yellow" style={{animation:"pulse 1.5s infinite"}}>LIVE</span>}
              {isDone && <span className="tag tag-green">CONCLUÍDO</span>}
              {!backupRunning && !isDone && <span className="tag tag-gray">IDLE</span>}
            </div>

            {backupProgress ? (
              <div>
                {/* overall progress */}
                <div className="flex justify-between" style={{fontSize:12,color:"var(--text2)",marginBottom:7}}>
                  <span>{isDone?"Backup finalizado":`Enviando ${backupProgress.done}/${backupProgress.total} arquivos...`}</span>
                  <span className="mono">{totalPct}%</span>
                </div>
                <div className="progress" style={{marginBottom:14}}><div className="progress-fill" style={{width:`${totalPct}%`,background:isDone?"var(--green)":undefined}}/></div>

                {/* current file */}
                {backupProgress.current && (
                  <div className="bk-item">
                    <div className="bk-item-icon" style={{background:"rgba(42,171,238,.12)"}}><Spinner size={14}/></div>
                    <div style={{flex:1}}>
                      <div className="flex items-center justify-between" style={{marginBottom:5}}>
                        <span style={{fontSize:13,fontWeight:500}}>{backupProgress.current.filename}</span>
                        <span style={{fontSize:11,color:"var(--tg)",fontFamily:"var(--mono)"}}>{backupProgress.current.speed_mbps} MB/s</span>
                      </div>
                      <div className="progress" style={{height:3}}>
                        <div className="progress-fill" style={{width:`${backupProgress.current.percent}%`}}/>
                      </div>
                    </div>
                    <span className="mono" style={{fontSize:11,color:"var(--tg)",width:32,textAlign:"right"}}>{backupProgress.current.percent}%</span>
                  </div>
                )}

                {/* summary stats */}
                <div className="flex gap-4" style={{marginTop:12,fontSize:12,color:"var(--text2)"}}>
                  {backupProgress.done>0 && <span style={{color:"var(--green)"}}>✅ {backupProgress.done} enviado{backupProgress.done>1?"s":""}</span>}
                  {backupProgress.skipped>0 && <span style={{color:"var(--yellow)"}}>⏭️ {backupProgress.skipped} pulado{backupProgress.skipped>1?"s":""}</span>}
                  {backupProgress.failed>0 && <span style={{color:"var(--red)"}}>❌ {backupProgress.failed} erro{backupProgress.failed>1?"s":""}</span>}
                  {backupProgress.bytes>0 && <span className="mono" style={{color:"var(--text3)"}}>{(backupProgress.bytes/1048576).toFixed(1)} MB total</span>}
                </div>
              </div>
            ) : (
              <div className="empty" style={{padding:"30px 20px"}}>
                <div className="empty-icon">📭</div>
                <div className="empty-title">Nenhum backup em execução</div>
                <div className="empty-sub">Adicione caminhos acima e clique em "Iniciar backup".</div>
              </div>
            )}
          </div>
        </div>

        {/* right col */}
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          <div className="card anim-fu1" style={{padding:20}}>
            <div style={{fontWeight:600,marginBottom:14}}>Agendamentos</div>
            {scheds.map((s,i)=>(
              <div key={i} className="sched-row">
                <div>
                  <div style={{fontSize:13,fontWeight:500}}>{s.label}</div>
                  <div style={{fontSize:11.5,color:"var(--text2)",marginTop:2}}>{s.sub}</div>
                </div>
                <Toggle on={s.on} onToggle={()=>setScheds(sc=>sc.map((x,j)=>j===i?{...x,on:!x.on}:x))}/>
              </div>
            ))}
            <div style={{fontSize:11,color:"var(--text3)",marginTop:10,padding:"8px 10px",background:"var(--bg)",borderRadius:8,border:"1px solid var(--border)"}}>
              ⚠️ Agendamentos ainda não conectados ao backend (em breve).
            </div>
          </div>

          {backupProgress && (
            <div className="card anim-fu2" style={{padding:20}}>
              <div style={{fontWeight:600,marginBottom:14}}>Resumo</div>
              {[
                ["Total",       `${backupProgress.total} arquivo${backupProgress.total>1?"s":""}`],
                ["Enviados",    `${backupProgress.done}`],
                ["Pulados",     `${backupProgress.skipped}`],
                ["Falhas",      `${backupProgress.failed}`],
                ["Dados env.",  `${(backupProgress.bytes/1048576).toFixed(1)} MB`],
              ].map(([k,v],i,a)=>(
                <div key={i} className="flex items-center justify-between" style={{padding:"9px 0",borderBottom:i<a.length-1?"1px solid var(--border)":"none"}}>
                  <span style={{fontSize:12.5,color:"var(--text2)"}}>{k}</span>
                  <span style={{fontSize:13,fontWeight:600,fontFamily:"var(--mono)"}}>{v}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── ACTIVITY ───────────────────────────────────────────────────────────── */
function ActivityPage({activityLog}) {
  const [dbJobs,setDbJobs]=useState([]);
  const [loadingJobs,setLoadingJobs]=useState(true);

  useEffect(()=>{
    backupApi.jobs(20).then(r=>{
      setDbJobs((r.data.jobs||[]).map(j=>({
        e: j.status==="done"?"\u2705":j.status==="failed"?"\u274c":j.status==="cancelled"?"\ud83d\udeab":"\u23f3",
        text: j.status==="done"
          ? `Backup conclu\u00eddo \u2014 ${j.files_sent} enviado${j.files_sent>1?"s":""}, ${j.files_skipped} pulado${j.files_skipped>1?"s":""} (${(j.bytes_sent/1048576).toFixed(1)} MB)`
          : j.status==="failed" ? `Backup falhou \u2014 ${j.files_failed} erro${j.files_failed>1?"s":""}`
          : j.status==="cancelled" ? "Backup cancelado pelo usu\u00e1rio"
          : `Backup em andamento \u2014 ${j.files_sent}/${j.files_total}`,
        time: j.finished_at ? new Date(j.finished_at).toLocaleString("pt-BR",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"})
          : j.started_at ? new Date(j.started_at).toLocaleString("pt-BR",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}) : "\u2014",
      })));
    }).catch(()=>{}).finally(()=>setLoadingJobs(false));
  },[]);

  return (
    <div style={{padding:26}}>
      <div className="anim-fu" style={{fontFamily:"var(--display)",fontSize:19,fontWeight:700,marginBottom:20}}>Hist\u00f3rico de Atividade</div>

      {activityLog.length>0 && (
        <div className="card anim-fu1" style={{padding:20,marginBottom:16}}>
          <div style={{fontSize:10,fontWeight:600,color:"var(--text3)",textTransform:"uppercase",letterSpacing:".1em",marginBottom:12}}>Sess\u00e3o atual</div>
          {activityLog.map((l,i)=>(
            <div key={i} className="log-item">
              <span style={{fontSize:16,flexShrink:0,marginTop:1}}>{l.e}</span>
              <div style={{flex:1}}><div style={{fontSize:13.5}}>{l.text}</div></div>
              <div style={{fontSize:11,color:"var(--text3)",fontFamily:"var(--mono)",flexShrink:0}}>{l.time}</div>
            </div>
          ))}
        </div>
      )}

      <div className="card anim-fu2" style={{padding:20}}>
        <div style={{fontSize:10,fontWeight:600,color:"var(--text3)",textTransform:"uppercase",letterSpacing:".1em",marginBottom:12}}>Hist\u00f3rico de backups</div>
        {loadingJobs ? (
          <div style={{textAlign:"center",padding:"30px"}}><Spinner size={20}/></div>
        ) : dbJobs.length>0 ? dbJobs.map((l,i)=>(
          <div key={i} className="log-item">
            <span style={{fontSize:16,flexShrink:0,marginTop:1}}>{l.e}</span>
            <div style={{flex:1}}><div style={{fontSize:13.5}}>{l.text}</div></div>
            <div style={{fontSize:11,color:"var(--text3)",fontFamily:"var(--mono)",flexShrink:0}}>{l.time}</div>
          </div>
        )) : (
          <div style={{padding:"30px 20px",textAlign:"center"}}>
            <div style={{fontSize:28,marginBottom:8}}>\ud83d\udced</div>
            <div style={{fontSize:13,color:"var(--text2)"}}>Nenhum backup registrado ainda.</div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── SETTINGS ───────────────────────────────────────────────────────────── */
function SettingsPage({onLogout, user, realChannels}) {
  const [notif,setNotif]=useState(true);
  const [startup,setStartup]=useState(true);
  const [tray,setTray]=useState(true);

  const ch = realChannels?.[0];

  return (
    <div style={{padding:26}}>
      <div className="anim-fu" style={{fontFamily:"var(--display)",fontSize:19,fontWeight:700,marginBottom:20}}>Configurações</div>
      <div style={{maxWidth:540,display:"flex",flexDirection:"column",gap:16}}>

        <div className="card anim-fu1" style={{padding:20}}>
          <div style={{fontSize:10,fontWeight:600,color:"var(--text3)",textTransform:"uppercase",letterSpacing:".1em",marginBottom:14}}>Conta Telegram</div>
          <div className="flex items-center gap-3" style={{marginBottom:14}}>
            <div className="avatar" style={{width:42,height:42,fontSize:15,borderRadius:12}}>{user?.first_name?.[0]||"?"}</div>
            <div>
              <div style={{fontWeight:600,fontSize:14}}>{splitName(user?.first_name)} {user?.last_name||""}</div>
              <div style={{fontSize:12,color:"var(--text3)",fontFamily:"var(--mono)"}}>+{user?.phone||"..."}</div>
              {user?.username && <div style={{fontSize:11,color:"var(--text3)"}}>@{user.username}</div>}
            </div>
            <span className="tag tag-green" style={{marginLeft:"auto"}}>Conectado</span>
          </div>
          <div style={{height:1,background:"var(--border)",marginBottom:14}}/>
          <div style={{fontSize:12,color:"var(--text2)",marginBottom:10}}>Canal de backup</div>
          <div className="flex items-center gap-3" style={{padding:"13px 14px",background:"var(--bg2)",borderRadius:10,border:"1px solid var(--border)"}}>
            <span style={{fontSize:20}}>📦</span>
            <div>
              <div style={{fontSize:13,fontWeight:500}}>{ch?.name || "Nenhum canal"}</div>
              <div style={{fontSize:11,color:"var(--text3)",fontFamily:"var(--mono)"}}>
                {ch ? `canal ${ch.type||"privado"} · id ${ch.id}` : "configure TELEVAULT_CHANNEL_ID no .env"}
              </div>
            </div>
            <span className={`tag ${ch?"tag-green":"tag-gray"}`} style={{marginLeft:"auto"}}>{ch?"Ativo":"—"}</span>
          </div>
          <button className="btn btn-danger btn-sm w-full" style={{marginTop:14,justifyContent:"center"}} onClick={onLogout}>
            <Icon n="trash" size={13}/>Desconectar conta
          </button>
        </div>

        <div className="card anim-fu2" style={{padding:20}}>
          <div style={{fontSize:10,fontWeight:600,color:"var(--text3)",textTransform:"uppercase",letterSpacing:".1em",marginBottom:14}}>Preferências</div>
          {[
            {label:"Notificações",         sub:"Alertas ao concluir ou falhar",         val:notif,    set:setNotif},
            {label:"Iniciar com o sistema",sub:"Inicia automaticamente no login",        val:startup,  set:setStartup},
            {label:"Minimizar para bandeja",sub:"Fica na system tray ao fechar",        val:tray,     set:setTray},
          ].map((s,i)=>(
            <div key={i} className="sched-row">
              <div>
                <div style={{fontSize:13.5,fontWeight:500}}>{s.label}</div>
                <div style={{fontSize:12,color:"var(--text2)",marginTop:2}}>{s.sub}</div>
              </div>
              <Toggle on={s.val} onToggle={()=>s.set(v=>!v)}/>
            </div>
          ))}
        </div>

        <div className="card anim-fu3" style={{padding:20}}>
          <div style={{fontSize:10,fontWeight:600,color:"var(--text3)",textTransform:"uppercase",letterSpacing:".1em",marginBottom:14}}>Sobre</div>
          {[
            ["Versão",     "0.1.0-alpha"],
            ["Base",       "fork de TGDrive"],
            ["Licença",    "MIT"],
            ["Plataforma", "Linux · RegataOS / openSUSE"],
            ["Telegram API","MTProto · Telethon"],
          ].map(([k,v],i,a)=>(
            <div key={i} className="flex items-center justify-between" style={{padding:"9px 0",borderBottom:i<a.length-1?"1px solid var(--border)":"none"}}>
              <span style={{fontSize:12.5,color:"var(--text2)"}}>{k}</span>
              <span style={{fontSize:12.5,fontFamily:"var(--mono)"}}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── APP ─────────────────────────────────────────────────────────────────── */
const NAV = [
  {id:"dashboard", label:"Dashboard",     icon:"home"},
  {id:"files",     label:"Arquivos",      icon:"folder"},
  {id:"backup",    label:"Backup",        icon:"cloud"},
  {id:"activity",  label:"Atividade",     icon:"activity"},
  {id:"settings",  label:"Configurações", icon:"settings"},
];

export default function App() {
  const [setup,setSetup]=useState(true);
  const [checking,setChecking]=useState(true);
  const [page,setPage]=useState("dashboard");
  const [backupRunning,setBackupRunning]=useState(false);
  const [user,setUser]=useState(null);
  const [realChannels,setRealChannels]=useState([]);
  const [realStats,setRealStats]=useState(null);
  const [backupProgress,setBackupProgress]=useState(null);
  const [activeJobId,setActiveJobId]=useState(null);
  const sseRef=useRef(null);

  const channelId = realChannels[0]?.id || null;
  const [activityLog,setActivityLog]=useState([]);

  const addLog = useCallback((emoji,text)=>{
    const now = new Date();
    const time = now.toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"});
    setActivityLog(prev=>[{e:emoji,text,time},...prev].slice(0,50));
  },[]);

  useEffect(()=>{
    authApi.status().then(async r=>{
      if(r.data.authorized){
        setSetup(false);
        // busca usuário e canais reais em paralelo
        try {
          const [meRes, chRes] = await Promise.all([
            authApi.me(),
            chApi.list(),
          ]);
          setUser(meRes.data);
          const chs = chRes.data.channels || [];
          setRealChannels(chs);
          // busca stats do primeiro canal
          if(chs.length > 0){
            try {
              const sRes = await statsApi.get(chs[0].id);
              setRealStats(sRes.data);
            } catch(e){ console.warn("stats:", e); }
          }
        } catch(e) { console.warn("Erro ao buscar dados reais:", e); }
      }
    }).catch(()=>{}).finally(()=>setChecking(false));
  },[]);

  const runBackup=useCallback(async (paths)=>{
    if(backupRunning || !channelId) return;
    if(!paths || paths.length===0){ setPage("backup"); return; }
    setBackupRunning(true);
    setPage("backup");
    setBackupProgress(null);
    try {
      const {data} = await backupApi.start(channelId, paths);
      setActiveJobId(data.job_id);
      setBackupProgress({status:"running",total:data.total_files,done:0,skipped:0,failed:0,bytes:0,current:null});
      addLog("⚡",`Backup iniciado — ${data.total_files} arquivo${data.total_files>1?"s":""}`);
      // SSE stream
      const BASE = import.meta.env.VITE_API_URL || "http://localhost:8001";
      const es = new EventSource(`${BASE}/api/backup/progress/${data.job_id}`);
      sseRef.current = es;
      es.onmessage = (e) => {
        const payload = JSON.parse(e.data);
        if(payload.status==="done"){
          es.close();
          sseRef.current=null;
          setBackupRunning(false);
          setActiveJobId(null);
          setBackupProgress(prev=>({...prev,status:"done"}));
          const prev = backupProgress||payload;
          addLog("✅",`Backup concluído — ${prev.done||0} enviado${(prev.done||0)>1?"s":""}, ${((prev.bytes||0)/1048576).toFixed(1)} MB`);
          // refresh stats
          statsApi.get(channelId).then(r=>setRealStats(r.data)).catch(()=>{});
        } else {
          setBackupProgress(payload);
        }
      };
      es.onerror = ()=>{ es.close(); sseRef.current=null; setBackupRunning(false); setActiveJobId(null); };
    } catch(err){
      console.error("Erro ao iniciar backup:", err);
      setBackupRunning(false);
      alert("Erro ao iniciar backup: " + (err?.response?.data?.detail || err.message));
    }
  },[backupRunning, channelId]);

  if(checking) return <><G/><div style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"var(--bg)"}}>
    <Spinner size={28}/>
  </div></>;
  if(setup) return <><G/><Wizard onDone={()=>setSetup(false)}/></>;

  return (
    <><G/>
    <div style={{display:"flex",height:"100vh",overflow:"hidden"}}>
      <div className="sidebar">
        <div className="sidebar-logo">
          <div className="logo-mark"><Icon n="tg" size={17} color="white"/></div>
          <div className="logo-text">Tele<span>Vault</span></div>
        </div>
        <div className="nav-section">
          <div className="nav-section-label">Menu</div>
          {NAV.map(n=>(
            <div key={n.id} className={`nav-item ${page===n.id?"active":""}`} onClick={()=>setPage(n.id)}>
              <Icon n={n.icon} size={16}/>
              <span>{n.label}</span>
              {n.id==="backup"&&backupRunning&&(
                <span style={{marginLeft:"auto",width:8,height:8,borderRadius:"50%",background:"var(--yellow)",animation:"pulse 1.2s infinite",display:"block"}}/>
              )}
            </div>
          ))}
        </div>
        <div className="sidebar-bottom">
          <div className="user-row">
            <div className="avatar">{user?.first_name?.[0]||"?"}</div>
            <div>
              <div className="user-name">{splitName(user?.first_name)}</div>
              <div className="user-phone">{user?.phone ? `+${user.phone.slice(0,4)} ···· ${user.phone.slice(-4)}` : "..."}</div>
            </div>
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <div className="topbar">
          <div className="topbar-title">{NAV.find(n=>n.id===page)?.label}</div>
          {backupRunning&&(
            <div className="flex items-center gap-2" style={{marginLeft:14}}>
              <div className="status-dot yellow"/>
              <span style={{fontSize:12,color:"var(--yellow)"}}>Backup em andamento...</span>
            </div>
          )}
          <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:10}}>
            <div className="flex items-center gap-2">
              <div className={`status-dot ${backupRunning?"yellow":"green"}`}/>
              <span style={{fontSize:12,color:"var(--text2)"}}>Telegram</span>
            </div>
            <button className="btn btn-ghost btn-icon btn-sm"><Icon n="bell" size={15}/></button>
          </div>
        </div>

        <div style={{flex:1,overflow:"auto"}}>
          <div key={page} className="anim-fi" style={{height:"100%"}}>
            {page==="dashboard"&&<Dashboard setPage={setPage} runBackup={runBackup} backupRunning={backupRunning} backupProgress={backupProgress} user={user} realChannels={realChannels} realStats={realStats} channelId={channelId} activityLog={activityLog}/>}
            {page==="files"    &&<FilesPage realChannels={realChannels} addLog={addLog}/>}
            {page==="backup"   &&<BackupPage runBackup={runBackup} backupRunning={backupRunning} backupProgress={backupProgress} channelId={channelId}/>}
            {page==="activity" &&<ActivityPage activityLog={activityLog}/>}
            {page==="settings" &&<SettingsPage onLogout={async()=>{try{await authApi.signOut();}catch(e){console.warn(e);}if(sseRef.current){sseRef.current.close();sseRef.current=null;}setSetup(true);setUser(null);setRealChannels([]);setRealStats(null);setBackupProgress(null);setActiveJobId(null);setBackupRunning(false);setActivityLog([]);setPage("dashboard");}} user={user} realChannels={realChannels}/>}
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
